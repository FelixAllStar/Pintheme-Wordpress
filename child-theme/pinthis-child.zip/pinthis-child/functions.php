<?php

function pinthis_child_add_styles() {
	// Enqueue the parent stylesheet
	wp_enqueue_style('pinthis-style', get_template_directory_uri() . '/style.css', array(), '1.6.5', 'all');
	// Enqueue the child stylesheet
	wp_enqueue_style('pinthis-child-style', get_stylesheet_uri(), array('pinthis-style'));
}
add_action('wp_enqueue_scripts', 'pinthis_child_add_styles');

?>